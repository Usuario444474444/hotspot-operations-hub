const express = require('express');
const router = express.Router();
console.log(
    'HOTSPOT ROUTES LOADED'
);

const {
    getHotspotTickets,
    getHistoricalHotspotTickets,
    getTicketActivity,
    getTicketAttachments,
    getAttachmentFile
} = require('../services/serviceNowService');

router.get('/api/hotspot', async (req, res) => {

    try {

        res.json(
            await getHotspotTickets()
        );

    } catch (e) {

        console.log(
            'ERROR COMPLETO:',
            e.response?.data || e
        );

        res.status(500).json({
            error: e.message,
            detail: e.response?.data || null
        });

    }

});

router.get(
    '/api/attachment/:sysId',
    async (req, res) => {

        try {

            const file =
                await getAttachmentFile(
                    req.params.sysId
                );

            res.setHeader(
                'Content-Type',
                file.headers['content-type']
            );

            res.send(file.data);

        } catch (e) {

            res.status(500).json({
                error: e.message
            });

        }
    }
);
router.get(
    '/api/ticket/:sysId/activity',
    async (req, res) => {

        try {

            const data =
                await getTicketActivity(
                    req.params.sysId
                );

            res.json(data);

        } catch (e) {

            res.status(500).json({
                error: e.message
            });

        }

    }
);
router.get(
    '/api/hotspot-historico',
    async (req, res) => {

        try {

            const data =
                await getHistoricalHotspotTickets();

            res.json(data);

        } catch (e) {

            console.log(
                'ERROR HISTORICO:',
                e.response?.data || e
            );

            res.status(500).json({
                error: e.message
            });

        }

    }
);
router.get(
    '/api/ticket/:sysId/attachments',
    async (req, res) => {

        try {

            const data =
                await getTicketAttachments(
                    req.params.sysId
                );

            return res.json(data);

        } catch (e) {

            console.log(
                'ERROR ATTACHMENTS:',
                e.response?.data || e.message
            );

            return res.status(500).json({
                error: e.message
            });

        }

    }
);
module.exports = router;