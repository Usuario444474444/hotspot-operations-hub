# HOH-V010-SVC-ServiceNowService

Version: 10.0.0

## Objetivo
Servicio de integración con ServiceNow para Hotspot Operations Hub.

## Mejoras
- Consulta múltiples torres.
- Extracción de SAP.
- Normalización de estados cerrados/resueltos.
- Preparado para lógica avanzada de duplicados.
- Campos extendidos para futuras categorías.

## Instalación
1. Reemplazar el archivo serviceNowService.js.
2. Configurar variables SNOW_INSTANCE, SNOW_USER y SNOW_PASSWORD.
3. Reiniciar Node.js.

## Control de versión
HOH-V010-SVC-ServiceNowService.zip
