const express = require('express');
const app = express();

app.use(express.json({
    limit: '200mb'
}));


app.use(express.static('src/public'));

const tickets = require('./routes/tickets');
const tiendas = require('./routes/tiendas');
const dashboard = require('./routes/dashboard');
const browserTools = require('./routes/browser-tools');
const hotspot = require('./routes/hotspot');
const controlFolios =
    require('./routes/controlFolios');

app.use(tickets);
app.use(tiendas);
app.use(dashboard);
app.use(browserTools);
app.use(hotspot);
app.use(controlFolios);

app.get('/api/test', (req, res) => {
    res.json({
        ok: true,
        version: 'V5'
    });
});
let syncStatus = {
    ok: true,
    lastSuccess: new Date().toISOString(),
    lastError: null
};

app.get('/api/sync-status', (req, res) => {

    res.json(syncStatus);

});
app.listen(3000, () => {
    console.log('HOH-V5 running');
});